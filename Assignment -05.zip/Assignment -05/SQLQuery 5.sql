SELECT * FROM SubjectAllotments;
