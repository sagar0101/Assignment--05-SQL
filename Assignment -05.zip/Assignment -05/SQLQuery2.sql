-- Insert data into SubjectAllotments
INSERT INTO SubjectAllotments (StudentID, SubjectID, Is_Valid)
VALUES 
('159103036', 'PO1491', 1),
('159103036', 'PO1492', 0),
('159103036', 'PO1493', 0),
('159103036', 'PO1494', 0),
('159103036', 'PO1495', 0);

-- Insert data into SubjectRequest
INSERT INTO SubjectRequest (StudentID, SubjectID)
VALUES 
('159103036', 'PO1496');
