
--Execute the Stored Procedure
EXEC UpdateSubjectAllotment '159103036', 'PO1496';
